<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php @include 'header.php'; ?>

<section class="heading">
    <h3>about us</h3>
    <p> <a href="home.php">home</a> / about </p>
</section>

<section class="about">

    <div class="flex">

        <div class="image">
            <img src="images/about-img-1.png" alt="">
        </div>

        <div class="content">
            <h3>why choose us?</h3>
            <p>Choose us for unparalleled quality and service. With a passion for perfection, we deliver exquisite floral arrangements crafted with precision and care. Our dedicated team is committed to exceeding your expectations, ensuring every experience with us is memorable and delightful. Trust us to bring your floral visions to life, with creativity, reliability, and a personal touch that sets us apart.</p>
            <a href="shop.php" class="btn">shop now</a>
        </div>

    </div>

    <div class="flex">

        <div class="content">
            <h3>what we provide?</h3>
            <p>Discover a world of floral wonders with us. We offer an exquisite selection of fresh blooms, stunning arrangements, and personalized floral services to elevate every occasion. From weddings to corporate events, birthdays to anniversaries, our passion for flowers shines through in every creation. Let us help you convey your sentiments with style and elegance, making every moment unforgettable.</p>
            <a href="contact.php" class="btn">contact us</a>
        </div>

        <div class="image">
            <img src="images/about-img-2.jpg" alt="">
        </div>

    </div>

    <div class="flex">

        <div class="image">
            <img src="images/about-img-3.jpg" alt="">
        </div>

        <div class="content">
            <h3>who we are?</h3>
            <p>We are your dedicated floral artisans, passionate about bringing beauty and joy into your life through our exquisite creations. With a commitment to quality, creativity, and personalized service, we strive to exceed your expectations every time. Whether you're celebrating life's special moments or simply brightening someone's day, we are here to provide you with the finest blooms and exceptional service, making every experience with us truly memorable.</p>
            <a href="#reviews" class="btn">clients reviews</a>
        </div>

    </div>

</section>

<section class="reviews" id="reviews">

    <h1 class="title">client's reviews</h1>

    <div class="box-container">

        <div class="box">
            <img src="images/pic-1.png" alt="">
            <p>"Beautiful flowers, excellent service. Thank you!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Edward John</h3>
        </div>

        <div class="box">
            <img src="images/pic-2.png" alt="">
            <p>"Amazing service and stunning arrangements. Highly recommended!"</p>
            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
            </div>
            <h3>Natalia Gomez</h3>
        </div>



    </div>

</section>











<?php @include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>